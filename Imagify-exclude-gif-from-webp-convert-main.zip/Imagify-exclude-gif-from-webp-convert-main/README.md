# Imagify - Exclude Gif From WebP Convert

This is a simple helper plugin, to exclude Gif files from being converted to WebP when using Imagify.

This helper plugin was build for a test. 
